package pac;
import pac.Alumno;
import pac.Modulo;
import pac.Profesor;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import java.io.*;
import java.util.*;

public class Main {
	public static void main(String[] args) {

		System.out.println("Iniciando");
		
		Configuration cfg = new Configuration();
		
		//Unica instancia de sessionFactory en nuestra sesion
		
		SessionFactory sessionFactory = cfg.buildSessionFactory(new StandardServiceRegistryBuilder().configure().build());
		
		Session session = sessionFactory.openSession();
		
		System.out.println("Configuracion terminada");
		
		Set<Modulo>alumno_modulo = new HashSet<Modulo>();
		
		Modulo M03B = new Modulo ("Programacion B", "M03B");
		Modulo M06 = new Modulo("Acceso a Datos", "M06");
		Modulo M08 = new Modulo("Desarrollo de aplicaciones moviles", "M08");
		Modulo M09 = new Modulo("Servicios y procesos", "M09");
		
		Profesor profesor = new Profesor("Alvaro", "Hombre");
		
		Alumno alumno1 = new Alumno("Juan", "Espaniola", 26, "Hombre", alumno_modulo);
		Alumno alumno2 = new Alumno("Pedro", "Andorrana", 21, "Hombre", alumno_modulo);
		Alumno alumno3 = new Alumno("Marta", "Espaniola", 19, "Mujer", alumno_modulo);
		Alumno alumno4 = new Alumno("Carla", "Francesa", 35, "Mujer", alumno_modulo);
		
		alumno1.modulos.add(M06);
		alumno1.modulos.add(M03B);
		alumno1.modulos.add(M08);
		alumno1.modulos.add(M09);
		
		alumno2.modulos.add(M03B);
		alumno2.modulos.add(M06);
		alumno2.modulos.add(M09);
		
		alumno3.modulos.add(M08);
		alumno3.modulos.add(M09);
	
		alumno4.modulos.add(M08);
		alumno4.modulos.add(M06);
		alumno4.modulos.add(M09);
		
		Transaction tx = session.beginTransaction();
		session.save(alumno1);
		tx.commit();
		System.out.println(alumno1.toString());
		
		
		tx = session.beginTransaction();
		session.save(M03B);
		tx.commit();
		System.out.println(M03B.toString());
		
		tx = session.beginTransaction();
		session.save(M06);
		tx.commit();
		System.out.println(M06.toString());
		
		tx = session.beginTransaction();
		session.save(M08);
		tx.commit();
		System.out.println(M08.toString());
		
		tx = session.beginTransaction();
		session.save(M09);
		tx.commit();
		System.out.println(M09.toString());
		
		
		tx = session.beginTransaction();
		session.save(alumno2);
		tx.commit();
		System.out.println(alumno2.toString());
		
		tx = session.beginTransaction();
		session.save(alumno3);
		tx.commit();
		System.out.println(alumno3.toString());
		
		tx = session.beginTransaction();
		session.save(alumno4);
		tx.commit();
		System.out.println(alumno4.toString());
		
		tx = session.beginTransaction();
		session.save(profesor);
		tx.commit();
		System.out.println(profesor.toString());
		
		Query query = session.createQuery("FROM Alumno");
		List list = query.list();
		for(int i = 0; i<list.size(); i++)
		{
			System.out.println(list.get(i).toString());
		}
			
	        session.close();
	        sessionFactory.close();
		}
}